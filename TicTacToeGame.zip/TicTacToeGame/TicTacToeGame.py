import random
import os
import csv


class Player:
    def __init__(self, symbol):
        self.symbol = symbol

    def make_move(self, board):
        pass


class HumanPlayer(Player):
    def make_move(self, board):
        while True:
            try:
                move = int(input("Enter your move (1-9): "))
                if 1 <= move <= 9 and board[move - 1] == ' ':
                    return move - 1
                else:
                    print("Invalid move. Try again.")
            except ValueError:
                print("Invalid input. Please enter a number.")


class AIPlayer(Player):
    def make_move(self, board):
        available_moves = [i for i, val in enumerate(board) if val == ' ']
        return random.choice(available_moves)


class PlayerFactory:
    @staticmethod
    def create_player(player_type, symbol):
        if player_type == 'human':
            return HumanPlayer(symbol)
        elif player_type == 'ai':
            return AIPlayer(symbol)
        else:
            raise ValueError("Invalid player type")


def read_csv(filename):
    data = {}
    try:
        with open(filename, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                data[row['Player']] = int(row['Wins'])
    except FileNotFoundError:
        pass
    return data


def write_csv(filename, data):
    with open(filename, 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=['Player', 'Wins'])
        writer.writeheader()
        for player, wins in data.items():
            writer.writerow({'Player': player, 'Wins': wins})


def update_wins(filename, player):
    data = read_csv(filename)
    if player in data:
        data[player] += 1
    else:
        data[player] = 1
    write_csv(filename, data)


class Game:
    _instance = None

    @staticmethod
    def get_instance():
        if Game._instance is None:
            Game._instance = Game()
        return Game._instance

    def __init__(self):
        self.board = [' ' for _ in range(9)]
        self.current_player = None
        self.players = []

    def initialize_players(self):
        symbol1 = input("Enter symbol for Player 1 (X or O): ").upper()
        symbol2 = 'X' if symbol1 == 'O' else 'O'
        player_type1 = input("Enter player type for Player 1 (human or ai): ").lower()
        player_type2 = input("Enter player type for Player 2 (human or ai): ").lower()

        self.players = [
            PlayerFactory.create_player(player_type1, symbol1),
            PlayerFactory.create_player(player_type2, symbol2)
        ]
        self.current_player = random.choice(self.players)

    def print_board(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        print("\n {} | {} | {} ".format(self.board[0], self.board[1], self.board[2]))
        print("-----------")
        print(" {} | {} | {} ".format(self.board[3], self.board[4], self.board[5]))
        print("-----------")
        print(" {} | {} | {} \n".format(self.board[6], self.board[7], self.board[8]))

    def check_winner(self, symbol):
        winning_combinations = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6]
        ]
        for combo in winning_combinations:
            if all(self.board[i] == symbol for i in combo):
                return True
        return False

    def check_draw(self):
        return ' ' not in self.board

    def switch_player(self):
        self.current_player = self.players[0] if self.current_player == self.players[1] else self.players[1]

    @staticmethod
    def display_player_stats(filename):
        stats = read_csv(filename)
        for player, wins in stats.items():
            if player == "draw":
                print(f"Draw happened {wins} times.")
            else:
                print(f"{player} has won {wins} games.")

    def play(self):
        filename = 'game_results.csv'
        self.initialize_players()
        self.print_board()

        while True:
            move = self.current_player.make_move(self.board)
            self.board[move] = self.current_player.symbol
            self.print_board()

            if self.check_winner(self.current_player.symbol):
                print(f"Player {self.current_player.symbol} wins!")
                update_wins(filename, f"Player {self.current_player.symbol}")
                break
            elif self.check_draw():
                print("It's a draw!")
                update_wins(filename, "draw")
                break

            self.switch_player()


if __name__ == "__main__":
    game = Game.get_instance()
    game.display_player_stats('game_results.csv')
    game.play()