import unittest
from unittest.mock import patch
import io
import os
from TicTacToeGame import Game

class TestTicTacToeGame(unittest.TestCase):

    def setUp(self):
        self.game = Game.get_instance()
        self.game.board = [' ' for _ in range(9)]
        self.game.players = []

    def test_check_winner(self):
        # Test horizontal win
        self.game.board = ['X', 'X', 'X', ' ', ' ', ' ', ' ', ' ', ' ']
        self.assertTrue(self.game.check_winner('X'))

    def test_check_draw(self):
        # Test for draw
        self.game.board = ['X', 'O', 'X', 'O', 'X', 'O', 'O', 'X', 'O']
        self.assertTrue(self.game.check_draw())

        # Test for not draw
        self.game.board = ['X', ' ', 'X', 'O', 'X', 'O', 'O', 'X', 'O']
        self.assertFalse(self.game.check_draw())

    @patch('sys.stdout', new_callable=io.StringIO)
    @patch('builtins.input', side_effect=['X', 'human', 'O', 'ai'])
    def test_play_game(self, mock_input, mock_stdout):
        self.game.play()
        output = mock_stdout.getvalue()
        self.assertIn("It's a draw!", output)

    def tearDown(self):
        if os.path.exists('game_results.csv'):
            os.remove('game_results.csv')


if __name__ == "__main__":
    unittest.main()
